import json
import boto3
import base64
import os

s3_client = boto3.client("s3")
BUCKET_NAME = os.environ.get("UPLOAD_BUCKET_NAME")

def lambda_handler(event, context):
    try:
        # Extract content-type from headers
        content_type = event["headers"].get("Content-Type", "")

        # Handle file upload via JSON (base64 encoded)
        if content_type == "application/json":
            body = json.loads(event["body"])
            file_content = base64.b64decode(body["file_data"])
            file_name = body.get("file_name", "uploaded_file.json")

        # Handle multipart/form-data
        elif "multipart/form-data" in content_type:
            body = event["body"]  # API Gateway passes raw form data
            file_name = event["headers"].get("X-File-Name", "uploaded_file.json")
            file_content = base64.b64decode(body)

        else:
            return {
                "statusCode": 400,
                "body": json.dumps({"error": "Unsupported content type"})
            }

        # Upload to S3
        s3_object_key = f"uploads/{file_name}"
        s3_client.put_object(Bucket=BUCKET_NAME, Key=s3_object_key, Body=file_content)

        return {
            "statusCode": 200,
            "body": json.dumps({"message": "File uploaded successfully", "s3_key": s3_object_key})
        }

    except Exception as e:
        return {
            "statusCode": 500,
            "body": json.dumps({"error": str(e)})
        }
